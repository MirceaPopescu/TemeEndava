package com.endava.junit.read;

import java.util.List;

import com.endava.junit.entities.Employee;

public interface ReaderInterface {

	public List<Employee> readEmployees ();
	
}
